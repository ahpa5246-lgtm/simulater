/*
    Copyright (C) Paul Falstad and Iain Sharp

    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once

#include "../core/CircuitElm.h"

class InverterElm : public CircuitElm {
public:
    bool showPropertiesOnCreate() override { return false; }
    ELM_CLASS(InverterElm)
    void addRoutingObstacle(WireRouter &wr) override;
    static constexpr int FLAG_DEMORGAN = 1 << 3;
    double slewRate;  // V/ns
    double highVoltage;
    double lastOutputVoltage = 0;
    Polygon gatePoly;
    Point pcircle, center;

    InverterElm(int xx, int yy);
    InverterElm(int xa, int ya, int xb, int yb, int f, StringTokenizer &st);

    void dumpXml(XmlElement *doc, XmlElement *elem) override;
    void undumpXml(CircuitXMLDeserializer &xml) override;
    int getDumpType() override { return 'I'; }
    void setPoints() override;
    int getVoltageSourceCount() override { return 1; }
    void setHighVoltage(double hv) override { highVoltage = hv; }
    void stamp() override;
    void startIteration() override { lastOutputVoltage = nodes[1]->v; }
    void doStep() override;
    double getVoltageDiff() override { return nodes[0]->v; }
    // no current path through inverter input, but indirect path through output to ground
    bool validate() override { return validateRailNode(1); }
    bool getConnection(int, int) override { return false; }
    bool hasGroundConnection(int n1) override { return n1 == 1; }
    double getCurrentIntoNode(int n) override { return n == 1 ? current : 0; }
    void draw(Graphics &g) override;
    void getInfo(std::vector<std::string> &arr) override;
    int getShortcut() override { return '1'; }
    std::optional<EditInfo> getEditInfo(int n) override;
    void setEditValue(int n, EditInfo &ei) override;
};
