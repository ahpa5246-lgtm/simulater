/*
    Copyright (C) Paul Falstad and Iain Sharp

    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "CrossSwitchElm.h"

#include "../core/FindPathInfo.h"
#include "../core/Graphics.h"
#include "../core/SimulationManager.h"
#include "../core/VoltageSource.h"

CrossSwitchElm::CrossSwitchElm(int xx, int yy, bool mm) : SwitchElm(xx, yy, mm) {
    noDiagonal = true;
}

CrossSwitchElm::CrossSwitchElm(int xa, int ya, int xb, int yb, int f, StringTokenizer &st)
    : SwitchElm(xa, ya, xb, yb, f, st) {
    noDiagonal = true;
}

void CrossSwitchElm::setPoints() {
    SwitchElm::setPoints();
    calcLeads(32);
    throwPosts = newPointArray(2 * poleCount);
    throwLeads = newPointArray(4 * poleCount);
    poleLeads = newPointArray(poleCount);
    polePosts = newPointArray(poleCount);
    linePoints = newPointArray(2);
    crossPoints = newPointArray(6);
    for (int i = 0; i != poleCount; i++) {
        int offset = -i * openhs * 3;
        interpPoint(point1, point2, polePosts[i], 0, offset);
        interpPoint(lead1, lead2, poleLeads[i], 0, offset);
        interpPoint(point1, point2, throwPosts[i * 2], 1, offset - openhs);
        interpPoint(lead1, lead2, throwLeads[i * 4], 1, offset - openhs);
        interpPoint(point1, point2, throwPosts[i * 2 + 1], 1, offset + openhs);
        interpPoint(lead1, lead2, throwLeads[i * 4 + 1], 1, offset + openhs);
        interpPoint(lead1, lead2, throwLeads[i * 4 + 2], 1, offset + openhs * 0.33);
        if (useIECSymbol())
            interpPoint(lead1, lead2, throwLeads[i * 4 + 3], 1.2, offset - openhs * 0.33);
        else
            interpPoint(lead1, lead2, throwLeads[i * 4 + 3], 1, offset - openhs);
    }
    double dp = 16 / dn;
    interpPoint(point1, point2, crossPoints[0], 1 + dp, openhs);
    interpPoint(point1, point2, crossPoints[1], 1 + dp * 2, openhs);
    interpPoint(point1, point2, crossPoints[2], 1 + dp * 3, openhs);
    interpPoint(point1, point2, crossPoints[3], 1 + dp * 2, -openhs);
    interpPoint(point1, point2, crossPoints[4], 1 + dp, -openhs * 4);
    interpPoint(point1, point2, crossPoints[5], 1 + dp * 3, -openhs * 4);
}

void CrossSwitchElm::draw(Graphics &g) {
    setBbox(point1, point2, 1);
    adjustBbox(crossPoints[2], crossPoints[5]);

    setVoltageColor(g, nodes[1]->v);
    drawThickLine(g, crossPoints[1], crossPoints[2]);
    drawThickLine(g, crossPoints[1], crossPoints[3]);
    drawThickLine(g, crossPoints[3], throwPosts[0]);
    drawThickLine(g, throwPosts[0], throwPosts[3]);
    setVoltageColor(g, nodes[3]->v);
    drawThickLine(g, throwPosts[2], crossPoints[5]);
    drawThickLine(g, throwPosts[1], crossPoints[0]);
    drawThickLine(g, crossPoints[0], crossPoints[4]);

    for (int i = 0; i != poleCount; i++) {
        setVoltageColor(g, nodes[i * 2]->v);
        drawThickLine(g, polePosts[i], poleLeads[i]);
        setVoltageColor(g, nodes[i * 2 + 1]->v);
        if (useIECSymbol())
            drawThickLine(g, throwLeads[i * 4], throwLeads[i * 4 + 2]);
        drawThickLine(g, throwPosts[i * 2], throwLeads[i * 4]);
        setVoltageColor(g, nodes[3 - i * 2]->v);
        drawThickLine(g, throwPosts[i * 2 + 1], throwLeads[i * 4 + 1]);

        if (!needsHighlight())
            g.setColor(lightGrayColor);

        if (i < poleCount - 1) {
            int offset = -i * openhs * 3;
            int adj = position * -3;
            interpPoint(point1, point2, linePoints[0], 0.5, offset - openhs * (0.5 - position) + adj);
            interpPoint(point1, point2, linePoints[1], 0.5, offset - openhs * 3 - openhs * (0.5 - position) + 7 + adj);
            g.setLineDash(4, 4);
            g.drawLine(linePoints[0], linePoints[1]);
            g.setLineDash(0, 0);
        }

        if (!needsHighlight())
            g.setColor(whiteColor);
        drawThickLine(g, poleLeads[i], throwLeads[i * 4 + 3 - position * 2]);

        curcounts[i] = updateDotCount(currents[i], curcounts[i]);
        drawDots(g, polePosts[i], poleLeads[i], curcounts[i]);
        drawDots(g, throwLeads[i * 4 + position], throwPosts[i * 2 + position], curcounts[i]);
        if (i == 1 && position == 0)
            drawDots(g, throwPosts[2], crossPoints[5], curcounts[1]);
        if (i == 0 && position == 1) {
            drawDots(g, throwPosts[1], crossPoints[0], curcounts[0]);
            drawDots(g, crossPoints[0], crossPoints[4], curcounts[0]);
            drawDots(g, crossPoints[4], crossPoints[5], curcounts[0]);
        }
        if (i == 1 && position == 1)
            drawDots(g, throwPosts[3], throwPosts[0], curcounts[1]);
        drawDots(g, throwPosts[0], crossPoints[3], curcounts[position]);
        drawDots(g, crossPoints[3], crossPoints[1], curcounts[position]);
        drawDots(g, crossPoints[1], crossPoints[2], curcounts[position]);
    }

    drawPosts(g);
    drawPost(g, throwPosts[0]);
    drawPost(g, crossPoints[4]);
}

double CrossSwitchElm::getCurrentIntoNode(int n) {
    if (n == 0 || n == 2)
        return -currents[n / 2];
    if (position == 0)
        return currents[n / 2];
    return currents[1 - n / 2];
}

void CrossSwitchElm::setCurrent(VoltageSource *vs, double c) {
    if (vs == voltageSources[0])
        currents[0] = c;
    else
        currents[1] = c;
}

Rectangle CrossSwitchElm::getSwitchRect() {
    return Rectangle(poleLeads[0].x, poleLeads[0].y, 0, 0)
        .unite(Rectangle(throwLeads[1].x, throwLeads[1].y, 0, 0))
        .unite(Rectangle(throwLeads[poleCount * 4 - 4].x, throwLeads[poleCount * 4 - 4].y, 0, 0));
}

Point CrossSwitchElm::getPost(int n) {
    if (n == 0 || n == 2)
        return polePosts[n / 2];
    if (n == 1)
        return crossPoints[2];
    return crossPoints[5];
}

void CrossSwitchElm::calculateCurrent() {
    if (resistance > 0) {
        for (int i = 0; i != poleCount; i++) {
            int dst = (position == 0) ? i * 2 + 1 : 3 - i * 2;
            currents[i] = (nodes[i * 2]->v - nodes[dst]->v) / resistance;
        }
    }
}

void CrossSwitchElm::setVoltageSource(int j, VoltageSource *vs) {
    voltageSources[j] = vs;
    vs->setNodes(nodes[j * 2], nodes[j * 2 + 1]);
}

void CrossSwitchElm::stamp() {
    if (position == 0) {
        for (int i = 0; i != poleCount; i++) {
            if (resistance > 0)
                sim->stampResistor(nodes[i * 2], nodes[i * 2 + 1], resistance);
            else
                sim->stampVoltageSource(nodes[i * 2], nodes[i * 2 + 1], voltageSources[i], 0);
        }
    } else {
        for (int i = 0; i != poleCount; i++) {
            if (resistance > 0)
                sim->stampResistor(nodes[i * 2], nodes[3 - i * 2], resistance);
            else
                sim->stampVoltageSource(nodes[i * 2], nodes[3 - i * 2], voltageSources[i], 0);
        }
    }
}

bool CrossSwitchElm::getConnection(int n1, int n2) {
    if (position == 0)
        return comparePair(n1, n2, 0, 1) || comparePair(n1, n2, 2, 3);
    else
        return comparePair(n1, n2, 0, 3) || comparePair(n1, n2, 2, 1);
}

void CrossSwitchElm::getInfo(std::vector<std::string> &arr) {
    arr[0] = "cross switch";
    for (int i = 0; i != poleCount; i++)
        arr[i + 1] = "I" + std::to_string(i + 1) + " = " + getCurrentDText(currents[i]);
}

bool CrossSwitchElm::validate() {
    if (resistance > 0)
        return true;
    for (int i = 0; i != poleCount; i++) {
        int dst = (position == 0) ? i * 2 + 1 : 3 - i * 2;
        FindPathInfo fpi(FindPathInfo::VOLTAGE, this, getNode(i * 2), sim);
        if (fpi.findPath(getNode(dst))) {
            resistance = .001;
            return false;
        }
    }
    return true;
}

std::optional<EditInfo> CrossSwitchElm::getEditInfo(int n) {
    if (n == 0)
        return EditInfo::createCheckbox("IEC Symbol", useIECSymbol());
    if (n == 1)
        return getKeyShortcutEditInfo();
    if (n == 2) {
        EditInfo ei("On Resistance (ohms)", resistance);
        ei.setNonNegative();
        return ei;
    }
    return std::nullopt;
}

void CrossSwitchElm::setEditValue(int n, EditInfo &ei) {
    if (n == 0) {
        flags = ei.changeFlag(flags, SwitchElm::FLAG_IEC);
        setPoints();
    }
    if (n == 1)
        setKeyShortcutEditValue(ei);
    if (n == 2)
        resistance = ei.value;
}
